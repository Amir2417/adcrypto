<?php

namespace App\Constants;

class SiteSectionConst{
    const BANNER_SECTION            = "Banner Section";
    const SECURITY_SECTION          = "Security Section";
    const HOW_ITS_WORK_SECTION      = "How Its Work Section";
    const DOWNLOAD_APP_SECTION      = "Download App";
    const STATISTIC_SECTION         = "Statistic Section";
    const CALL_TO_ACTION_SECTION    = "Call To Action Section";
    const FOOTER_SECTION            = "Footer Section";
    const NEWSLETTER_SECTION        = "News Letter Section";
    const ABOUT_SECTION             = "About Section";
    const FAQ_SECTION               = "Faq Section";
    const SERVICE_SECTION           = "Service Section";
    const BLOG_SECTION              = "Blog Section";
    const CONTACT_SECTION           = "Contact Section";
    const LOGIN_SECTION             = "Login Section";
    const REGISTER_SECTION          = "Register Section";

}